---
title: "React & Next.js: Como aprender?"
date: "25/11/2021"
---

Você sabia que eu tenho um ⚛️ Curso de React ⚛️ com
**70 videoaulas**, mais de **11 horas de conteúdo** com
**vários projetos desenvolvidos**?

Visite [reactdiretoaoponto.com.br](https://www.reactdiretoaoponto.com.br/)
para ter **acesso vitalício**!

> 7 dias de garantia de satisfação

### Conteúdo:

- Fundamentos do **React**
- **Hooks**
- **Next.js**
- **Local Storage**
- Consultar e enviar dados para **APIs**
- **Context API**
- **CSS Modules**
- _mais um monte de coisas bacanas!_ 🤩
