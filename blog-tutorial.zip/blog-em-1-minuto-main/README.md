# Blog em 1 minuto

Será que eu consigo demonstrar como criar um blog em apenas 1 minuto? 😮

- 👉 Vídeo: https://www.youtube.com/watch?v=PiWvZX9eLw8
- 👉 Post: https://www.lucascaton.com.br/2021/12/07/criando-um-blog-com-nextjs

## Meu curso de React:

https://www.reactdiretoaoponto.com.br/
